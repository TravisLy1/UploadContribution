﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;

using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UploadContribution
{
    public enum eState
    {
        Idle, Transferring
    }
    public partial class FormMain : Form
    {
        private string m_machineName;

        //private List<Task> m_tasks;
        private Dictionary<string, XferJobInfo> m_jobs;
        private List<string> m_todoFiles;
        
        private FileSystemWatcher m_watcher;
        public FormMain()
        {

            InitializeComponent();
            //m_tasks = new List<Task>();
            m_jobs = new Dictionary<string, XferJobInfo>();
            m_todoFiles = new List<string>();

            startWatching();
            updateStatus();
            tsLabelDestination.Text = Program.DestinationFolder;
            tsLabelWatchFolder.Text = Program.WatchFolder;
            m_machineName = Environment.MachineName;
            this.Text = m_machineName;
        }


    
        /// <summary>
        /// When a new file is created, copied into this folder
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void m_watcher_Created(object sender, FileSystemEventArgs e)
        {
            lock (m_todoFiles)
            {
                // File may be started to created, but not completely copied
                m_todoFiles.Add(e.FullPath);
                addLine("Add to Queue: " + e.FullPath, Color.DarkBlue);
                updateStatus();
               
                timerTransfer.Interval = 5000;
                timerTransfer.Start();
            }
        }

        

        /// <summary>
        /// Need this to be non-blocking,  create a thread and run the rsync
        /// </summary>
        /// <param name="fileName"></param>
        private void doTransfer(string fileName)
        {
            lock (m_todoFiles)
                m_todoFiles.Remove(fileName);
            addLine("Transfering: " + fileName, Color.Blue);
            XferJobInfo xInfo = new XferJobInfo(fileName, Program.DestinationFolder);
            xInfo.OnCompleted += OnTransferCompleted;
            m_jobs.Add(fileName, xInfo);

            Action doUpload = () => XferJobInfo.XferFile(xInfo);
            Task t = new Task(doUpload);
            t.Start();
            updateStatus();
        }

        /// <summary>
        /// Transfer completed, could be success or failure
        /// </summary>
        /// <param name="sender"></param>
        void OnTransferCompleted(object sender)
        {
            XferJobInfo xInfo = (XferJobInfo)sender;
            m_jobs.Remove(xInfo.Source);
            if (xInfo.ReturnCode == 0)
            {
                addLine(xInfo.Source + " transferred successfully", Color.DarkGreen);
                // Completed succesfully
                // Delete file if return code is 0 
                File.Delete(xInfo.Source);
           
                // update the xferJobInfo associated with this file
                Program.TransferLog += xInfo.ToString();
                Program.TransferLog += "\r\n";

                if (m_jobs.Count == 0)
                {
                    //get the tag file
                    Program.GetTagFile();
                    addLine("Getting Tag File", Color.DarkGray);
                    // upload tag file
                    addLine("Updating Tag File", Color.DarkGray);
                    Program.SendTagFile();          // Send Tag file
                }
            }
            else
            {
                // Failed,  file is not removed
                addLine(xInfo.Source + " Failed to upload", Color.Red);      
                // Add back to todos
                m_todoFiles.Add(xInfo.Source);
            }
            updateStatus();
        }


        private bool IsLocked(string fileName)
        {
            try
            {
                Stream s = new FileStream(fileName, FileMode.Open);
                s.Close();
                return false;
            }
            catch
            {
                return true;
            }
        }

       

        private void startWatching()
        {
            // start watch folder
            if (Directory.Exists(Program.WatchFolder))
            {
                // start watching
                m_watcher = new FileSystemWatcher(Program.WatchFolder);
                m_watcher.NotifyFilter = NotifyFilters.LastAccess | NotifyFilters.LastWrite
                        | NotifyFilters.FileName | NotifyFilters.DirectoryName;
                m_watcher.Created += m_watcher_Created;
            
                m_watcher.EnableRaisingEvents = true;
                addLine("Monitor " + Program.WatchFolder);
                
            }
            else
            {
                addLine(Program.WatchFolder + " Does not exist!");
            }
        }

      
        private void tsButtonBrowse_Click(object sender, EventArgs e)
        {
            // Open dialog 
            if (openFolderDlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                // set the folder
               Program.WatchFolder = openFolderDlg.SelectedPath;
               startWatching();
            }
        }

        private delegate void UpdateStatusCallBack();
        private void updateStatus()
        {
            if (InvokeRequired)
            {
                UpdateStatusCallBack u = new UpdateStatusCallBack(updateStatus);
                this.BeginInvoke(u);
            }
            else
            {
                tsTextTodos.Text = m_todoFiles.Count.ToString();
                tsTextTransferring.Text = m_jobs.Count.ToString();
            }
        }

        private delegate void AddLineCallBack(string Value, Color? c=null);
        private void addLine(string line, Color? c =null )
        {
            Color color = c ?? Color.Black;

            if (InvokeRequired)
            {
                AddLineCallBack d = new AddLineCallBack(addLine);
                this.BeginInvoke(d, line, color);
            }
            else
            {

                string msg = DateTime.Now.ToLongTimeString() + " " + DateTime.Now.ToShortDateString();
                msg = msg + " " + line + "\n";
                AppendTrace(m_textTrace, msg, color );
                //m_textTrace.AppendText(msg + " " + line + "\n");
                //m_textTrace.Select(m_textTrace.Text.Length, 0);
                //m_textTrace.ScrollToCaret();// Do the dirty work of my method here.

                Application.DoEvents();
            }
        }

        private void timerTransfer_Tick(object sender, EventArgs e)
        {
            // check to see if todos a
            if (m_todoFiles.Count > 0)
            {                
                string fileName = m_todoFiles[0];
                if (!IsLocked(fileName))
                {
                    doTransfer(fileName);
                }                
            }
            
        }

        /// <summary>
        /// timestamp the message and add to the textbox.
        /// To prevent runtime faults should the amount
        /// of data become too large, trim text when it reaches a certain size.
        /// </summary>
        /// <param name="text"></param>
        private void AppendTrace(RichTextBox rtb, string text, Color textcolor)
        {
            // keep textbox trimmed and avoid overflow
            // when kiosk has been running for awhile

            Int32 maxsize = 1024000;
            Int32 dropsize = maxsize / 4;

            if (rtb.Text.Length > maxsize)
            {
                // this method preserves the text colouring
                // find the first end-of-line past the endmarker

                Int32 endmarker = rtb.Text.IndexOf('\n', dropsize) + 1;
                if (endmarker < dropsize)
                    endmarker = dropsize;

                rtb.Select(0, endmarker);
                rtb.Cut();
            }

            try
            {
                // trap exception which occurs when processing
                // as application shutdown is occurring

                rtb.SelectionStart = rtb.Text.Length;
                rtb.SelectionLength = 0;
                rtb.SelectionColor = textcolor;
                rtb.AppendText(text);
                rtb.ScrollToCaret();
                  //System.DateTime.Now.ToString("HH:mm:ss.mmm") + " " + text);
            }
            catch (Exception)
            {
            }
        }
    }
}
